create function "overlaps"(time without time zone, interval, time without time zone, time without time zone) returns boolean
    immutable
    parallel safe
    cost 1
    language sql
RETURN (($1, ($1 + $2)) OVERLAPS ($3, $4));

comment on function "overlaps"(time, interval, time, time) is 'intervals overlap?';

alter function "overlaps"(time, interval, time, time) owner to root;

