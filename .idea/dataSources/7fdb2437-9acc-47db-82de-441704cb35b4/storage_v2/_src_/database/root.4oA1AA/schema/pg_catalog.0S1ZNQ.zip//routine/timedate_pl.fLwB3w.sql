create function timedate_pl(time without time zone, date) returns timestamp without time zone
    immutable
    strict
    parallel safe
    cost 1
    language sql
RETURN ($2 + $1);

comment on function timedate_pl(time, date) is 'implementation of + operator';

alter function timedate_pl(time, date) owner to root;

